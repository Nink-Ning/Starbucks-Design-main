# 内部试用说明

DesignKit Starter V1 当前仅用于内部试用、方案验证和设计评审，不是正式对外发布包。

## 使用前提

- 需要可以读取本地文件或上传文本的 AI 工具。
- 生成的 HTML 需要联网加载固定 CDN 资源。
- 建议使用当前版本的 Chrome 或 Edge 打开。
- 预览时需要使用本地 HTTP 服务；Starter 本身不提供自动启动服务。

## 数据安全

- 不要在提示词、Mock 数据或 HTML 中输入真实客户数据、密码、令牌、内部接口地址或敏感业务信息。
- Demo 中的用户、门店、订单等数据必须使用虚构的本地 Mock 数据。
- 不要将生成的 HTML 直接部署到生产环境。

## 试用边界

- 只支持基础列表、卡片列表、基础表单和基础详情。
- Card List 只支持当前页面内的本地 Mock 选择和轻量批量操作，不支持跨页选择、复杂服务端批量操作或权限工作流。
- 不支持 Vue、真实接口、权限、上传、导出和工程项目。
- AI 生成结果必须经过浏览器预览和人工检查。
- `examples/list.html`、`examples/multi-select-card-list.html`、`examples/form.html` 和 `examples/detail.html` 是已完成本地浏览器回归的 Golden Example；`output/*.html` 不继承该验证状态。

本文件是内部使用说明，不构成法律许可证、第三方依赖声明或正式发布条款。
